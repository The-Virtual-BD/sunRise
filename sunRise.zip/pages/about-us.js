import React from 'react';
import About from '../components/Pages/company/About';

const aboutus = () => {
    return (
        <div>
            <About />

        </div>
    );
};

export default aboutus;