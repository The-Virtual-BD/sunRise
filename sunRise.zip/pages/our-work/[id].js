import React from "react";
import SingleWork from "../../components/Pages/OurWork/SingleWork";

const singleWork = () => {
	return (
		<div>
			<SingleWork />
		</div>
	);
};

export default singleWork;
