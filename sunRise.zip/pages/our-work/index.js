import React from 'react';
import Works from '../../components/Pages/OurWork/Works';

const index = () => {
    return (
        <div>
            <Works />
        </div>
    );
};

export default index;