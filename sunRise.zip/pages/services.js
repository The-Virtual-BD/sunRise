import React from 'react';
import Services from '../components/Pages/Services/Services';

const services = () => {
    return (
        <div>
            <Services />
        </div>
    );
};

export default services;