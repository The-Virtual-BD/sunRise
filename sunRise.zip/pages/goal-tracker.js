import React from 'react';
import GoalTracker from '../components/Pages/company/GoalTracker';

const goalTracker = () => {
    return (
        <div>
            <GoalTracker />
        </div>
    );
};

export default goalTracker;