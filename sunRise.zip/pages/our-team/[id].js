import React from "react";
import MemberDetails from "../../components/Pages/Teams/MemberDetails";

const Member = () => {
	return (
		<div>
			<MemberDetails />
		</div>
	);
};

export default Member;
