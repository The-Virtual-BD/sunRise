import React from 'react';
import Teams from '../../components/Pages/Teams/Teams';

const Team = () => {
    return (
        <div>
           <Teams />
        </div>
    );
};

export default Team;