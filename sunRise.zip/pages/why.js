import React from 'react';
import Why from '../components/Pages/Why/Why';

const why = () => {
    return (
        <div>
            <Why />
        </div>
    );
};

export default why;