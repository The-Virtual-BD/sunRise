import React from "react";
import ProductDetails from "../../components/Pages/Products/ProductDetails";

const singleProduct = () => {
	return (
		<div>
			<ProductDetails />
		</div>
	);
};

export default singleProduct;
