import React from 'react';
import Products from '../../components/Pages/Products/Products';

const index = () => {
    return (
        <div>
            <Products />
        </div>
    );
};

export default index;