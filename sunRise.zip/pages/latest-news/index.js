import React from "react";
import News from "../../components/Pages/company/News";

const latestNews = () => {
	return (
		<div>
			<News />
		</div>
	);
};

export default latestNews;
