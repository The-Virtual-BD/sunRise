import React from 'react';
import NewsDetails from '../../components/Pages/company/NewsDetails';

const newsDetails = () => {
    return (
        <div>
            <NewsDetails />
        </div>
    );
};

export default newsDetails;