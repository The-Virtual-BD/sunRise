import React from 'react';
import Contacts from '../components/Pages/company/Contacts';

const contacts = () => {
    return (
        <div>
            <Contacts />
        </div>
    );
};

export default contacts;