"use strict";
exports.id = 978;
exports.ids = [978];
exports.modules = {

/***/ 9286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Homepage_Brand)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/images/Brand/logo-verizon.svg
/* harmony default export */ const logo_verizon = ({"src":"/_next/static/media/logo-verizon.2a24b937.svg","height":28,"width":121});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react-fast-marquee"
var external_react_fast_marquee_ = __webpack_require__(5700);
var external_react_fast_marquee_default = /*#__PURE__*/__webpack_require__.n(external_react_fast_marquee_);
// EXTERNAL MODULE: ./components/Context/Context.js + 1 modules
var Context = __webpack_require__(9903);
// EXTERNAL MODULE: ./url.js
var url = __webpack_require__(8742);
;// CONCATENATED MODULE: ./components/Homepage/Brand.js







const brandImg = [
    {
        id: 1,
        img: "/images/Brand/vbd.jpg"
    },
    {
        id: 2,
        img: "/images/Brand/moth.jpg"
    },
    {
        id: 3,
        img: "/images/Brand/postal-logo.png"
    },
    {
        id: 4,
        img: "/images/Brand/works.jpg"
    },
    {
        id: 5,
        img: "/images/Brand/logo-nyse.svg"
    },
    {
        id: 6,
        img: "/images/Brand/logo-point-one.png"
    },
    {
        id: 7,
        img: "/images/Brand/works.jpg"
    },
    {
        id: 8,
        img: "/images/Brand/logo-nyse.svg"
    },
    {
        id: 9,
        img: "/images/Brand/logo-point-one.png"
    }
];
const Brand = ()=>{
    const { brands , brandLoading  } = (0,Context/* useCollection */.Kx)();
    if (brandLoading) {
        return /*#__PURE__*/ jsx_runtime_.jsx("p", {
            children: "Loading..."
        });
    }
    ;
    if (!brandLoading && brands.length === 0) {
        return /*#__PURE__*/ jsx_runtime_.jsx("p", {
            children: "Empty Brand"
        });
    }
    ;
    // console.log(brands);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-white overflow-hidden",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " flex items-center justify-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_fast_marquee_default()), {
                speed: 50,
                className: "w-full flex items-center justify-center",
                children: brands?.map((data)=>/*#__PURE__*/ jsx_runtime_.jsx(BrandCard, {
                        data: data
                    }, data._id))
            })
        })
    });
};
/* harmony default export */ const Homepage_Brand = (Brand);
const BrandCard = ({ data  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: `${url/* baseURL */.v}/${data?.brandImg}`,
            alt: data?.brandName,
            className: "brand-img"
        })
    });
};


/***/ }),

/***/ 2778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sharedPage_StaticData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5758);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Context_Context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9903);
/* harmony import */ var _url__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8742);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);








const Team = ()=>{
    const { team , teamLoading  } = (0,_Context_Context__WEBPACK_IMPORTED_MODULE_5__/* .useCollection */ .Kx)();
    if (teamLoading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-center text-lg",
            children: "Loading..."
        });
    }
    ;
    if (!teamLoading && team.length === 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-center text-lg",
            children: "Empty Team"
        });
    }
    ;
    // console.log(team);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "text-paraclr py-20 px-5 ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "max-w-7xl mx-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "header-design",
                    children: "Our Team Members"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid grid-cols-1 lg:grid-cols-4 gap-20 lg:gap-10 mt-20 mb-20 max-w-7xl mx-auto",
                children: team?.map((team)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MemberCard, {
                        team: team
                    }, team._id)).slice(0, 4)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "bg-green-500 hover:bg-green-700 rounded-sm text-white px-6 lg:px-10 py-1.5 lg:py-3 text-bold text-lg lg:text-2xl mt-10",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                        href: "/our-team",
                        className: "flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "View All"
                            }),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsArrowRight, {})
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Team);
const MemberCard = ({ team  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { _id , memberName , memberImg , memberDesi  } = team;
    const handleMemberPage = (id)=>{
        router.push(`our-team/${id}`);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "team_card ",
            onClick: ()=>handleMemberPage(_id),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "team_img",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: `${_url__WEBPACK_IMPORTED_MODULE_7__/* .baseURL */ .v}/${memberImg}`,
                        alt: memberName
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "team_info",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "font-semibold",
                            children: memberName
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-sm lg:text-base",
                            children: memberDesi
                        })
                    ]
                })
            ]
        })
    });
};


/***/ })

};
;