"use strict";
exports.id = 978;
exports.ids = [978];
exports.modules = {

/***/ 9286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Homepage_Brand)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/images/Brand/logo-verizon.svg
/* harmony default export */ const logo_verizon = ({"src":"/_next/static/media/logo-verizon.2a24b937.svg","height":28,"width":121});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-fast-marquee"
var external_react_fast_marquee_ = __webpack_require__(5700);
var external_react_fast_marquee_default = /*#__PURE__*/__webpack_require__.n(external_react_fast_marquee_);
;// CONCATENATED MODULE: ./components/Homepage/Brand.js





const brandImg = [
    {
        id: 1,
        img: "/images/Brand/vbd.jpg"
    },
    {
        id: 2,
        img: "/images/Brand/moth.jpg"
    },
    {
        id: 3,
        img: "/images/Brand/postal-logo.png"
    },
    {
        id: 4,
        img: "/images/Brand/works.jpg"
    },
    {
        id: 5,
        img: "/images/Brand/logo-nyse.svg"
    },
    {
        id: 6,
        img: "/images/Brand/logo-point-one.png"
    },
    {
        id: 7,
        img: "/images/Brand/works.jpg"
    },
    {
        id: 8,
        img: "/images/Brand/logo-nyse.svg"
    },
    {
        id: 9,
        img: "/images/Brand/logo-point-one.png"
    }
];
const Brand = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-white border-[1px] border-gray-300 h-20 overflow-hidden",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " flex items-center justify-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_fast_marquee_default()), {
                speed: 50,
                className: "w-full h-20 flex items-center justify-center",
                children: brandImg.map((data)=>/*#__PURE__*/ jsx_runtime_.jsx(BrandCard, {
                        img: data.img
                    }, data.id))
            })
        })
    });
};
/* harmony default export */ const Homepage_Brand = (Brand);
const BrandCard = ({ img  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            className: "mx-10",
            src: img,
            width: 100,
            height: 80,
            alt: ""
        })
    });
};


/***/ }),

/***/ 2778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sharedPage_StaticData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5758);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__);





const Team = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "text-paraclr py-20 px-5 ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "max-w-7xl mx-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "header-design",
                    children: "Our Team Members"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid grid-cols-1 lg:grid-cols-4 gap-20 lg:gap-10 mt-20 mb-20 max-w-7xl mx-auto",
                children: _sharedPage_StaticData__WEBPACK_IMPORTED_MODULE_2__/* .teamMember.map */ .aX.map((team)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MemberCard, {
                        team: team
                    }, team.id))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "bg-green-500 hover:bg-green-700 rounded-sm text-white px-6 lg:px-10 py-1.5 lg:py-3 text-bold text-lg lg:text-2xl mt-10",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                        href: "/",
                        className: "flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "View All"
                            }),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsArrowRight, {})
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Team);
const MemberCard = ({ team  })=>{
    const { id , name , img , designation , linkedIn , github  } = team;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "team_card ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "team_img",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: img,
                        alt: name
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "team_info",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "font-semibold",
                            children: name
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-sm lg:text-base",
                            children: designation
                        })
                    ]
                })
            ]
        })
    });
};


/***/ })

};
;