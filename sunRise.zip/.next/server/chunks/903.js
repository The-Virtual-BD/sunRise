"use strict";
exports.id = 903;
exports.ids = [903];
exports.modules = {

/***/ 9903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ZP": () => (/* binding */ Context),
  "Kx": () => (/* binding */ useCollection)
});

// UNUSED EXPORTS: AppContext

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
// EXTERNAL MODULE: ./url.js
var url = __webpack_require__(8742);
;// CONCATENATED MODULE: ./components/Context/fetching.js

//Fetch FAQS
const fetchFAQs = async ()=>{
    const res = await fetch(`${url/* baseURL */.v}/faqs/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch Brand
const fetchBrand = async ()=>{
    const res = await fetch(`${url/* baseURL */.v}/brand/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch Products
const fetchProducts = async ()=>{
    const res = await fetch(`${url/* baseURL */.v}/products/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch News
const fetchNews = async ()=>{
    const res = await fetch(`${url/* baseURL */.v}/news/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch Teams
const fetchTeam = async ()=>{
    const res = await fetch(`${url/* baseURL */.v}/team/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch Work
const fetchWork = async ()=>{
    const res = await fetch(`${url/* baseURL */.v}/work/all`);
    const data = await res.json();
    return data?.data;
};

;// CONCATENATED MODULE: ./components/Context/Context.js





const AppContext = /*#__PURE__*/ (0,external_react_.createContext)();
const DataCollection = ({ children  })=>{
    const { data: faqs , isLoading: faqLoading  } = (0,external_react_query_.useQuery)("faqs", fetchFAQs);
    const { data: brands , isLoading: brandLoading  } = (0,external_react_query_.useQuery)("brands", fetchBrand);
    const { data: products , isLoading: productsLoading  } = (0,external_react_query_.useQuery)("products", fetchProducts);
    const { data: news , isLoading: newsLoading  } = (0,external_react_query_.useQuery)("news", fetchNews);
    const { data: team , isLoading: teamLoading  } = (0,external_react_query_.useQuery)("team", fetchTeam);
    const { data: work , isLoading: workLoading  } = (0,external_react_query_.useQuery)("work", fetchWork);
    // console.log(faqs,brands)
    const value = {
        faqs,
        faqLoading,
        brands,
        brandLoading,
        products,
        productsLoading,
        news,
        newsLoading,
        team,
        teamLoading,
        work,
        workLoading
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(AppContext.Provider, {
        value: value,
        children: children
    });
};
//Create Hooks for send data
const useCollection = ()=>{
    const context = (0,external_react_.useContext)(AppContext);
    return context;
};
/* harmony default export */ const Context = (DataCollection);


/***/ }),

/***/ 8742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ baseURL)
/* harmony export */ });
const baseURL = `https://server.ishtiuq.com`;


/***/ })

};
;